CAPITAL UNIQUE — LOGO PACK
Version 1.0 · August 2026
https://www.capitalunique.com


WHAT'S IN HERE

  capital-unique-coin-bronze.png              500 x 500    transparent
  capital-unique-coin-silver.png              500 x 500    transparent
  capital-unique-horizontal-bronze-on-dark.png       1040 x 360   transparent
  capital-unique-horizontal-silver-on-light.png       520 x 180   transparent

All four are PNG with a transparent background.


THE ONE RULE THAT MATTERS

The wordmark colour is baked into each horizontal lockup, so the file you
pick is dictated by the background it sits on:

  * Dark background  ->  use ...-bronze-on-dark.png   (wordmark is white)
  * Light background ->  use ...-silver-on-light.png  (wordmark is black)

Use the wrong one and the wordmark disappears into the background. The
filenames say which is which; follow them.

The two coin marks carry their own tile, so they stay legible on either a
light or a dark background. Match the finish to the setting for cohesion —
bronze in dark settings, silver in light ones.


CLEAR SPACE AND MINIMUM SIZE

Leave clear space on all four sides equal to the cap-height of the "C" in
"Capital". Nothing — type, an image edge, a rule, or another logo — may
enter that zone.

Minimum sizes:
  Horizontal lockup    120 px wide on screen  (about 32 mm in print)
  Coin                  32 px wide on screen  (about  9 mm in print)

Below these the coin's interior detail breaks up. If you need the mark
smaller than that, use the coin rather than shrinking the horizontal lockup.


NEVER

  * Recolour, tint, or apply gradients to the mark
  * Add shadows, glows, outlines, or any other effect
  * Stretch, squash, or rotate it
  * Redraw or re-typeset it, or set the name in a different typeface
  * Separate the coin from the wordmark to make a new lockup
  * Place it on a busy photograph without a solid panel or scrim behind it


BRAND COLOURS (for reference)

  Brandy Punch  #C56A31    primary accent
  Inkwell       #2C628D    cool counter-tone
  Void          #080808    the canonical dark background
  Off-white     #F2F2F2    the canonical light background

Typography is Source Serif 4 (headings) and Public Sans (body). Full colour,
typography, voice and compliance guidance is in the brand guidelines PDF:
https://www.capitalunique.com/brand/capital-unique-brand-guidelines.pdf


TWO THINGS THIS PACK DOES NOT INCLUDE

1. There is no SVG or other vector version. These marks exist only as
   raster artwork. If you need vector for large-format print, contact the
   press desk rather than tracing these files.

2. Two of the four possible colour pairings do not exist as artwork: a
   silver lockup with a white wordmark (for silver on a dark background),
   and a bronze lockup with a black wordmark (for bronze on a light
   background). Until they do, the finish cannot be chosen independently of
   the background. Ask the press desk if you need one of those.


CONTACT

Press desk — hello@capitalunique.com
Capital Unique, Level 26, 1 Bligh Street, Sydney NSW 2000

Capital Unique operates in the wholesale and commercial market. It does not
hold an Australian Credit Licence or an Australian Financial Services
Licence, and does not provide consumer credit, credit assistance, or
financial product advice. Please read the "Describing Us" section of the
brand guidelines before publishing.
